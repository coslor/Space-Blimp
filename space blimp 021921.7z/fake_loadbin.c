#include <stdint.h>
#include <stdio.h>

typedef uint8_t byte;

byte loadbin(char* filename, byte fname_len, byte device, unsigned int address) {
	int ret;
	
	ret = filename;
	ret = fname_len;
	ret = device;
	ret = address;
	
	return ret;
}
