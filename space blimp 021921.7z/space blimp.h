#ifndef SPACE_BLIMP_H
#define SPACE_BLIMP_H 1
#endif

#define CLR 9
//0x93 
#define CHROUT 0xffd2
#define CLR_SCRN 0xe544

#define Y_MIN 50
#define Y_MAX 250
#define X_MIN 16
#define X_MAX 319

#define NUM_MOBS 2

#define BLIMP 6
#define BOMB 7

#define R_BLIMP_SPR 193
#define R_BOMB_SPR 192
#define L_BLIMP_SPR 195
#define L_BOMB_SPR 194

typedef uint8_t byte;
typedef int8_t sbyte;

typedef uint16_t word;

typedef enum {BC_RIGHT, BC_TOP, BC_LEFT, BC_BOTTOM} CollisionType;
typedef struct MOB MOB;
typedef void (*CollisionHandler)(MOB*, CollisionType) ;
typedef void (*MovementHandler)(MOB* mob);

void set_sprite_x(byte, int);
extern  byte fastcall loadbin(char* filename, byte fname_len, byte device, unsigned int address);
void clr_screen();
//typedef void handle_collision(MOB mob, border_collision_type ct) CollisionHandler;
void init_mob(byte num, bool active, byte sprite_num, bool mcolor, byte sprite_ptr, 		\
	word x, bool expand_x, byte y, bool expand_y, sbyte xvel, sbyte yvel,byte color,	\
	CollisionHandler coll_handler, MovementHandler move_handler);

void move_mobs();
void sprite_switching_bouncy_border_collision_handler(struct MOB*, CollisionType);
void bouncy_border_collision_handler(MOB *mob, CollisionType type);
void sprite_switching_bouncy_border_collision_handler(MOB*, CollisionType);
void velocity_movement_handler(MOB*);
void handle_border_collision(MOB*, CollisionType);
int load_sprites(char *, byte);
void init_mobs();
void set_bit(byte *, byte, bool);



void move_mob(MOB*);
void move_mobs();
void draw_mobs();


struct  MOB {
	bool active;
	
	byte sprite_num;
	
	byte sprite_ptr;
	
	word x;
	byte y;
	
	byte color;
	
	bool mcolor;
	
	bool expand_x;
	bool expand_y;
	
	sbyte xvel;
	sbyte yvel;
		
	CollisionHandler coll_handler;
	MovementHandler move_handler;
	
};
