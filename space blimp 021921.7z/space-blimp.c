#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <c64.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "space blimp.h"

MOB mobs[NUM_MOBS];
char *sprite_defs=(char *)12288;
char *sprite_data_vicptr=(char *)2040;

char *screen = (char *)0x400;

int main(int argc, char **argv)
{

	int ret_code, ret_code2;
	char *fn  = "sprites.prg";
	char *fn2 = "sprites";
	byte dev;

	clr_screen();
	
	// read last used device number
	dev = *((byte*)0xba);
	if (dev < 8 || dev > 31) {
		dev = 8;
	}
	printf("device=%d\n",dev);
	
	//
	// sprite filename might depend on whether we're running on a real machine
	//	or an emulator, so try 'sprites.prg' first, then 'sprites'
	//
	ret_code=load_sprites(fn, dev);
	if (ret_code != 0) {
		printf("Failed to load '%s' with error code %d.\n Trying alternate filename '%s'...\n",
			fn, ret_code, fn2);
		ret_code2 = load_sprites(fn2,dev);
		
		if (ret_code2 != 0) {
			printf("Sprite load failed with code %d\n", ret_code);
			exit(ret_code); 
		}
	}
	else {
		printf("sprites loaded!\n");
	}
	
	VIC.spr_ena = 3; //SPRITE_0_MASK | SPRITE_1_MASK;
	VIC.spr_mcolor = 255;

	VIC.spr_mcolors[0] = COLOR_RED;
	VIC.spr_mcolors[1] = COLOR_WHITE;
	
	VIC.spr_color[0] = COLOR_GRAY1;
	VIC.spr_color[1] = COLOR_GRAY1;
	
	printf("Space Blimp, motha motha!!!\n");

	
	init_mobs();
	draw_mobs();
	
	
	
	//while (true) {};
	

	while (true) {

		//TODO replace with an IRQ for rasterline 251
		while (VIC.rasterline<251) {};	//wait for raster to go off screen
		
		move_mobs();
		draw_mobs();
		
/*		
		
		 VIC.spr_pos[0].y = 50;
		 VIC.spr_pos[1].y = 50;
		 
		// right-pointing sprites
		sprite_data_vicptr[0]=193;
		sprite_data_vicptr[1]=192;
	
		for (i=16;i<319;i++) {
			while (VIC.rasterline<251) {};	//wait for raster to go off screen
			set_sprite_x(0,i);
			set_sprite_x(1,i);
			while (VIC.rasterline<250) {};	//wait for raster to go off screen
		}

		// left-pointing sprites		
		sprite_data_vicptr[0]=194;
		sprite_data_vicptr[1]=195;
		
		for (i=319;i>=16;i--) {
			while (VIC.rasterline<251) {};	//wait for raster to go off screen
			set_sprite_x(0,i);
			set_sprite_x(1,i);
			while (VIC.rasterline<250) {};	//wait for raster to go off screen
		}

		// right-pointing sprites
		sprite_data_vicptr[0]=193;
		sprite_data_vicptr[1]=192;

		for (i=16;i<170;i++) {
			while (VIC.rasterline<251) {};	//wait for raster to go off screen
			set_sprite_x(0,i);
			set_sprite_x(1,i);
			while (VIC.rasterline<250) {};	//wait for raster to go off screen
		}

		//drop the bomb
		for (i=50; i<250;i++) {
			while (VIC.rasterline>0) {};	//wait for raster to go off screen
			VIC.spr_pos[1].y=i;
			while (VIC.rasterline<250) {};	//wait for raster to go off screen
		}
*/	
	}
	
	return 0;
}

int load_sprites(char* fn, byte dev) {
	byte flen, ret_code;
	
	flen=(byte)strlen(fn);
	ret_code=loadbin(fn,flen,dev,0x3000);
	//printf("loadbin returned with code %d\n",ret_code);
	
	return ret_code;
}

void move_mobs() {
	int i;
	
	for (i=0;i<8;i++) {
		if (mobs[i].active == true) {
			move_mob(mobs+i);
		}
	}
}

void move_mob(MOB *m) {
	CollisionType ct=NULL;

	assert(m != NULL);
			
	m->x += m->xvel;
	if (m->x < X_MIN) {
		ct = BC_LEFT;
	} 
	else if (m->x > X_MAX) {
		ct = BC_RIGHT;
	}
		
	m->y += m->yvel;
	if (m->y < Y_MIN) {
		ct = BC_TOP;
	}
	else if (m->y > Y_MAX) {
		ct = BC_BOTTOM;
	}
		
	if ((ct != NULL) && (m->coll_handler != NULL)) {
		m->coll_handler(m, ct);
	}
}

void init_mobs() {
	init_mob(0, true, 0, true, 193, 16, false, 50, false, 1,0,COLOR_GRAY1,
		(CollisionHandler)sprite_switching_bouncy_border_collision_handler, velocity_movement_handler);

}

void init_mob(byte num, bool active, byte sprite_num, bool mcolor, byte sprite_ptr, 
	word x, bool expand_x, byte y, bool expand_y, sbyte xvel, sbyte yvel,byte color,
	CollisionHandler coll_handler, MovementHandler move_handler) {
		MOB *m = mobs + num;
		m->active = active;
		m->sprite_num = sprite_num;
		m->sprite_ptr = sprite_ptr;
		m->x = x;
		m->y = y;
		m->mcolor = mcolor;
		m->expand_x = expand_x;
		m->expand_y = expand_y;
		m->xvel = xvel;
		m->yvel = yvel;
		m->color = color;
		m->coll_handler = coll_handler;
		m->move_handler = move_handler;
	}
	

void set_bit(byte *val, byte bit_num, bool bit_val) {
	byte pwr2 = (2^bit_num);
	if (bit_val) {
		*val |= pwr2;
	}
	else {
		*val &= (0xFF - pwr2);
	}
}
void draw_mobs() {
	byte i;
	
	for (i=0; i < NUM_MOBS;i++) {
		MOB *m = mobs+i;
		
		if (m->active == true) {
			byte n = m->sprite_num;
			
			set_bit(&VIC.spr_ena,n,m->active);
			
			VIC.spr_pos[n].y = m->y;
			set_sprite_x(n,VIC.spr_pos[n].x);			
			
			sprite_data_vicptr[n]=m->sprite_ptr;		
			
			//set_bit(&VIC.spr_exp_x,n,m->expand_x);
			//set_bit(&VIC.spr_exp_y,n,m->expand_y);
		}
	}
}
	
void set_sprite_x(byte sprite_num, int x_pos) {
	byte high_byte;
	
	assert(sprite_num<=8);
	
	VIC.spr_pos[sprite_num].x = (x_pos & 0xff);
	
	high_byte = x_pos / 256;
	set_bit(&VIC.spr_hi_x,sprite_num,(high_byte != 0));
}

void clr_screen() {
	__asm__("jsr %w", CLR_SCRN);
}

void bouncy_border_collision_handler(MOB *mob, CollisionType type) {
	assert(mob != NULL);
	if ((type == BC_LEFT) || (type == BC_RIGHT)) {
		mob->xvel *= -1;
	}
	else if ((type == BC_TOP) || (type == BC_BOTTOM)) {
		mob->yvel *= -1;
	}
}

void sprite_switching_bouncy_border_collision_handler(MOB *mob, CollisionType type) {
	assert(mob != NULL && type != NULL);
	
	bouncy_border_collision_handler(mob, type);
	if (type == BC_LEFT) {
		mob->sprite_ptr +=1;
	}
	else if (type == BC_RIGHT) {
		mob->sprite_ptr-=1;
	}
}

void velocity_movement_handler(MOB *mob) {
		printf("**VELOCITY_MOVEMENT_HANDLER**\n");
}

void handle_border_collision(MOB *mob, CollisionType type){
	printf("**handle_border_collision**\n");
	//exit(1);
}


